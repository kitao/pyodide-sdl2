from ._readers import ascent, aero, ecg, camera, nino
from ._wavelab_signals import demo_signal
