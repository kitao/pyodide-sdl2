"""pytest: avoid already-imported warning: PYTEST_DONT_REWRITE."""

__version__ = '3.4.1'
