
# THIS FILE IS GENERATED FROM PYWAVELETS SETUP.PY
short_version = '1.4.1'
version = '1.4.1'
full_version = '1.4.1'
git_revision = 'c3fc042c815e92fbc44c9e3995607bb79d0bb86b'
release = True

if not release:
    version = full_version
