
# A simple module for testing the dis module.

def f(): pass
def g(): pass
